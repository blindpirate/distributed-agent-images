#import "Object.h"

@interface Protocol : Object @end
