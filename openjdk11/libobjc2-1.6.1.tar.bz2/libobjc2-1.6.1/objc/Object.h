#include <objc/runtime.h>

@interface Object
{
	Class isa;
}
@end
