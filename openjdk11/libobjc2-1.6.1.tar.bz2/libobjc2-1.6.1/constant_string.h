#ifndef CONSTANT_STRING_CLASS
#	ifdef GNUSTEP
#		define CONSTANT_STRING_CLASS "NSConstantString"
#	else
#		define CONSTANT_STRING_CLASS "NXConstantString"
#	endif
#endif
